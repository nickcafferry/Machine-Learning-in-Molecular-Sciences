Paclet[Name->"QMMLPack", Version->"0.1.0"]
